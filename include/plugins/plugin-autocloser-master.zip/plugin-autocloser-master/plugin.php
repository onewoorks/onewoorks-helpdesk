<?php return array(
 'id' => 'clonemeagain:autocloser', # notrans
 'version' => '2.0',
 'name' => 'Ticket Closer',
 'author' => 'clonemeagain@gmail.com',
 'description' => 'Changes ticket statuses based on age.',
 'url' => 'https://github.com/clonemeagain/osticket-plugin-closer',
 'plugin' => 'class.CloserPlugin.php:CloserPlugin'
);
